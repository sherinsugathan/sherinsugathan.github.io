<?php
/**
 * Common theme features.
 */

/**
 * Common assets registration
 */
function ci_theme_register_common_assets() {
	$theme = wp_get_theme();
	wp_register_style( 'ci-theme-common', get_template_directory_uri() . '/common/css/global.css', array(), $theme->get( 'Version' ) );
}
add_action( 'init', 'ci_theme_register_common_assets', 8 );
