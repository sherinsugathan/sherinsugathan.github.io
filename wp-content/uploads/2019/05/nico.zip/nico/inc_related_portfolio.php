<?php if ( ci_setting( 'show_related_portfolios' ) == 'enabled' ): ?>
	<?php $related = ci_get_related_posts( get_the_ID(), 3 ); ?>
	<?php if ( $related->have_posts() ): ?>
		<aside class="related">
			<h3 class="section-title"><?php ci_e_setting( 'related_portfolios_text' ); ?></h3>
			<div class="row item-list">
				<?php while( $related->have_posts() ): $related->the_post(); ?>
					<div class="col-md-4 col-sm-6 col-xs-6">
						<div class="item">
							<a href="<?php the_permalink(); ?>">
								<?php the_post_thumbnail( 'ci_portfolio_thumb' ); ?>
							</a>
						</div>
					</div>
				<?php endwhile; ?>
				<?php wp_reset_postdata(); ?>
			</div>
		</aside>
	<?php endif; ?>
<?php endif; ?>