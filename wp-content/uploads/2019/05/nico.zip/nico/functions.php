<?php
	get_template_part('panel/constants');

	load_theme_textdomain( 'ci_theme', get_template_directory() . '/lang' );

	// This is the main options array. Can be accessed as a global in order to reduce function calls.
	$ci = get_option(THEME_OPTIONS);
	$ci_defaults = array();

	// The $content_width needs to be before the inclusion of the rest of the files, as it is used inside of some of them.
	if ( ! isset( $content_width ) ) $content_width = 750;

	//
	// Let's bootstrap the theme.
	//
	get_template_part('panel/bootstrap');

	//
	// Let WordPress manage the title.
	//
	add_theme_support( 'title-tag' );

	//
	// HTML5 Support for galleries
	//
	add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption' ) );

	add_ci_theme_support( 'custom_footer_background' );

	//
	// Define our various image sizes.
	//
	add_theme_support( 'post-thumbnails' );
	set_post_thumbnail_size( 500, 500, true );
	add_image_size( 'ci_portfolio_thumb', 400, 270, true);
	$portfolio_height = intval( ci_setting( 'portfolio_single_height' ) );
	if( !empty( $portfolio_height ) ) {
		add_image_size( 'ci_portfolio_slider', 750, $portfolio_height, true );
	} else {
		add_image_size( 'ci_portfolio_slider', 750 );
	}

	add_fancybox_support();

	// Let the user choose a color scheme on each post individually.
	add_ci_theme_support( 'post-color-scheme', array( 'page', 'post', 'portfolio' ) );

	add_action( 'after_setup_theme', 'ci_theme_convert_slider_options_v1_to_v2' );
	if ( ! function_exists( 'ci_theme_convert_slider_options_v1_to_v2' ) ):
	function ci_theme_convert_slider_options_v1_to_v2() {
		global $ci, $ci_defaults;

		if ( isset( $ci['internal_slider_sync'] ) && ! isset( $ci_defaults['internal_slider_sync'] ) ) {
			unset(
				$ci['internal_slider_autoslide'],
				$ci['internal_slider_timeout'],
				$ci['internal_slider_speed'],
				$ci['internal_slider_effect'],
				$ci['internal_slider_sync']
			);
			$new_sliders = array(
				'internal_slider_autoslide' => $ci_defaults['internal_slider_autoslide'],
				'internal_slider_effect'    => $ci_defaults['internal_slider_effect'],
				'internal_slider_direction' => $ci_defaults['internal_slider_direction'],
				'internal_slider_speed'     => $ci_defaults['internal_slider_speed'],
				'internal_slider_duration'  => $ci_defaults['internal_slider_duration'],
			);
			$ci = array_merge( $ci, $new_sliders );
			update_option( THEME_OPTIONS, $ci );
		}
	}
	endif;

	if ( ! defined( 'CI_THEME_WHITELABEL' ) || false === (bool) CI_THEME_WHITELABEL ) {
		add_filter( 'pt-ocdi/import_files', 'ci_theme_ocdi_import_files' );
		add_action( 'pt-ocdi/after_import', 'ci_theme_ocdi_after_import_setup' );
	}

	function ci_theme_ocdi_import_files( $files ) {
		if ( ! defined( 'CI_THEME_NAME' ) ) {
			define( 'CI_THEME_NAME', 'nico' );
		}

		$demo_dir_url = untrailingslashit( apply_filters( 'ci_theme_ocdi_demo_dir_url', 'https://www.cssigniter.com/sample_content/' . CI_THEME_NAME ) );

		// When having more that one predefined imports, set a preview image, preview URL, and categories for isotope-style filtering.
		$new_files = array(
			array(
				'import_file_name'           => esc_html__( 'Demo Import', 'ci_theme' ),
				'import_file_url'            => $demo_dir_url . '/content.xml',
				'import_widget_file_url'     => $demo_dir_url . '/widgets.wie',
			),
		);

		return array_merge( $files, $new_files );
	}

	function ci_theme_ocdi_after_import_setup() {
		// Set up nav menus.
		$main_menu = get_term_by( 'name', 'Nico', 'nav_menu' );

		set_theme_mod( 'nav_menu_locations', array(
			'ci_main_menu' => $main_menu->term_id,
		) );

		// Set up home and blog pages.
		$front_page_id = get_page_by_title( 'Home' );
		$blog_page_id  = get_page_by_title( 'Blog' );

		update_option( 'show_on_front', 'page' );
		update_option( 'page_on_front', $front_page_id->ID );
		update_option( 'page_for_posts', $blog_page_id->ID );
	}

	/**
	 * Common theme features.
	 */
	require_once get_theme_file_path( '/common/common.php' );
