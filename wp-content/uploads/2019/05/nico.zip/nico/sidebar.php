<div class="sidebar">
	<?php
		if ( is_singular('post') || is_archive() || is_home() ) {
			dynamic_sidebar('blog-sidebar');
		} else {
			dynamic_sidebar('main-sidebar');
		}
	?>
</div>