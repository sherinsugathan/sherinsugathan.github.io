<?php get_header(); ?>

<main class="main">
	<?php get_template_part( 'inc_hero' ); ?>

	<?php while ( have_posts() ) : the_post(); ?>

		<article id="post-<?php the_ID(); ?>" <?php post_class( 'entry' ); ?>>
			<h1 class="entry-title"><?php the_title(); ?></h1>

			<?php if( ci_has_image_to_show() ): ?>
				<figure class="entry-thumb <?php ci_e_setting( 'featured_single_align' ); ?>">
					<a href="<?php echo ci_get_featured_image_src( 'large' ); ?>" class="lightbox">
						<?php ci_the_post_thumbnail( array( 'noalign' => true ) ); ?>
					</a>
				</figure>
			<?php endif; ?>

			<div class="entry-content">
				<?php the_content(); ?>
				<?php wp_link_pages(); ?>
			</div>

		</article>

		<?php comments_template(); ?>

	<?php endwhile; ?>

</main>

<?php get_footer(); ?>