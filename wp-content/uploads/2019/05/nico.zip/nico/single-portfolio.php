<?php get_header(); ?>

<main class="main">
	<?php get_template_part( 'inc_hero' ); ?>

	<article id="post-<?php the_ID(); ?>" <?php post_class( 'entry' ); ?>>
		<h1 class="entry-title"><?php the_title(); ?></h1>
		<?php
			$gallery = ci_featgal_get_attachments();
			$slider  = get_post_meta( get_the_ID(), 'ci_cpt_portfolio_internal_slider', true );
		?>
		<?php if( $slider != 'disabled' ): ?>
			<?php if( $gallery->have_posts() ): ?>
				<figure class="entry-thumb">
					<?php
						$autoslide = ci_setting( 'internal_slider_autoslide' ) == 'enabled' ? '1' : '0';
						$effect    = ci_setting( 'internal_slider_effect' );
						$direction = ci_setting( 'internal_slider_direction' );
						$duration  = (string) ci_setting( 'internal_slider_duration' );
						$speed     = (string) ci_setting( 'internal_slider_speed' );
					?>
					<div class="flexslider portfolio-slider loading" data-animation="<?php echo esc_attr( $effect ); ?>" data-direction="<?php echo esc_attr( $direction ); ?>" data-slideshow="<?php echo esc_attr( $autoslide ); ?>" data-slideshowspeed="<?php echo esc_attr( $speed ); ?>" data-animationspeed="<?php echo esc_attr( $duration ); ?>">
						<ul class="slides">
							<?php while( $gallery->have_posts() ): $gallery->the_post(); ?>
								<li>
									<a href="<?php echo ci_get_image_src( get_the_ID(), 'large' ); ?>" class="lightbox" data-fancybox-group="gal">
										<?php $attachment = wp_prepare_attachment_for_js( get_the_ID() ); ?>
										<img src="<?php echo ci_get_image_src( get_the_ID(), 'ci_portfolio_slider' ); ?>" alt="<?php echo esc_attr( $attachment['alt'] ); ?>">
									</a>
								</li>
							<?php endwhile; ?>
						</ul>
					</div>
				</figure>
				<?php wp_reset_postdata(); ?>
			<?php endif; ?>
		<?php endif; ?>

		<?php
			$skills = get_the_term_list( get_the_ID(), 'skill', '', ', ' );
			$fields = get_post_meta( get_the_ID(), 'ci_cpt_portfolio_project_fields', true );
		?>
		<?php if( !empty( $fields ) || !empty( $skills ) ): ?>
			<table class="portfolio-info">
				<tbody>
					<?php if ( ! empty( $skills ) ): ?>
						<tr>
							<th><?php _e( 'Categories', 'ci_theme' ); ?></th>
							<td><?php echo $skills; ?></td>
						</tr>
					<?php endif; ?>
					<?php if( !empty($fields) ): ?>
						<?php foreach( $fields as $field ): ?>
							<tr>
								<th><?php echo $field['title']; ?></th>
								<td><?php echo make_clickable( $field['description'] ); ?></td>
							</tr>
						<?php endforeach; ?>
					<?php endif; ?>
				</tbody>
			</table>
		<?php endif; ?>

		<div class="entry-content">
			<?php the_content(); ?>
			<?php wp_link_pages(); ?>
		</div>

	</article>

	<?php get_template_part( 'inc_related_portfolio' ); ?>

</main>

<?php get_footer(); ?>