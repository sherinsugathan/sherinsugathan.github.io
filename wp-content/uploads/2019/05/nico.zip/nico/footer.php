			</div>
		</div>
	</div>
	<footer class="footer">
		<div class="container">
			<div class="row">
				<div class="col-sm-8 col-sm-offset-4">
					<div class="row">
						<div class="col-md-4">
							<?php dynamic_sidebar('footer-widgets-left'); ?>
						</div>
						<div class="col-md-4">
							<?php dynamic_sidebar('footer-widgets'); ?>
						</div>
						<div class="col-md-4">
							<?php dynamic_sidebar('footer-widgets-right'); ?>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="footer-bottom">
			<div class="container">
				<div class="row">
					<div class="col-lg-10 col-lg-offset-1">
						<p><?php echo ci_footer(); ?></p>
					</div>
				</div>
			</div>
		</div>
	</footer>
</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>