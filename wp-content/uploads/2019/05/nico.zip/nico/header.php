<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php do_action('after_open_body_tag'); ?>

<div id="page">
	<div class="container">
		<div class="row">
			<div class="col-md-4 col-sm-4">
				<header class="header">
					<?php ci_e_logo('<h1 class="logo ' . get_logo_class() . '">', '</h1>'); ?>
					<?php ci_e_slogan('<p class="tagline">', '</p>'); ?>
					<a class="mobile-toggle" href="#"></a>
				</header>
				<div class="side-wrap">
					<nav class="nav">
						<?php
							wp_nav_menu( array(
								'theme_location' 	=> 'ci_main_menu',
								'fallback_cb' 		=> '',
								'container' 		=> '',
								'menu_id' 			=> 'navigation',
								'menu_class' 		=> 'group'
							));
						?>
					</nav>

					<?php get_sidebar(); ?>

				</div>
			</div>

			<div class="col-md-8 col-sm-8">