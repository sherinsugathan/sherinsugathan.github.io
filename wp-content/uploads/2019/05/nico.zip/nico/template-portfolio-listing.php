<?php
/*
Template Name: Portfolio Listing
*/
?>

<?php get_header(); ?>

<main class="main">
	<?php get_template_part( 'inc_hero' ); ?>

	<?php while ( have_posts() ) : the_post(); ?>

		<?php
			$portfolio_columns = get_post_meta( get_the_ID(), 'ci_cpt_portfolio_columns', true );

			// Needed for installations updated from <= v2.0
			$portfolio_columns = ! empty( $portfolio_columns ) ? $portfolio_columns : 3;
		?>

		<div class="entry-content">
			<?php the_content(); ?>
		</div>

		<ul class="filter-nav">
			<li><a href="#filter" class="selected" data-filter="*"><?php esc_html_e( 'All Works', 'ci_theme' ); ?></a></li>
			<?php
				$skills = get_terms( 'skill', array(
					'hide_empty' => 0,
				) );
			?>
			<?php foreach ( $skills as $skill ) : ?>
				<li><a href="#filter" data-filter=".term-<?php echo esc_attr( $skill->term_id ); ?>"><?php echo esc_html( $skill->name ); ?></a></li>
			<?php endforeach; ?>
		</ul>

		<?php
			$q = new WP_Query( array(
				'post_type'      => 'portfolio',
				'posts_per_page' => -1,
			) );
		?>
		<div class="row item-list item-isotope">
			<?php while ( $q->have_posts() ) : $q->the_post(); ?>
				<?php
					$terms         = get_the_terms( get_the_ID(), 'skill' );
					$terms         = ! empty( $terms ) ? $terms : array();
					$terms_classes = implode( ' ', array_map( 'urldecode', wp_list_pluck( $terms, 'slug' ) ) );
					foreach ( wp_list_pluck( $terms, 'term_id' ) as $term_id ) {
						$terms_classes .= ' term-' . $term_id;
					}
				?>
				<div class="<?php echo esc_attr( ci_get_columns_class( $portfolio_columns ) ); ?> <?php echo esc_attr( $terms_classes ); ?>">
					<div class="item">
						<a href="<?php the_permalink(); ?>">
							<?php the_post_thumbnail( 'ci_portfolio_thumb' ); ?>
						</a>
					</div>
				</div>
			<?php endwhile; ?>
			<?php wp_reset_postdata(); ?>
		</div>
	<?php endwhile; ?>
</main>

<?php get_footer(); ?>
