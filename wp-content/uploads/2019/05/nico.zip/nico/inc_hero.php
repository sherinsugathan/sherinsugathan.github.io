<?php if ( ci_show_hero() ): ?>
	<div class="site-intro">
		<h2><?php ci_e_setting( 'hero_title' ); ?></h2>
		<p><?php ci_e_setting( 'hero_description' ); ?></p>
	</div>
<?php endif; ?>