<?php global $ci, $ci_defaults, $load_defaults; ?>
<?php if ($load_defaults===TRUE): ?>
<?php
	add_filter('ci_panel_tabs', 'ci_add_tab_color_options', 20);
	if( !function_exists('ci_add_tab_color_options') ):
		function ci_add_tab_color_options($tabs) 
		{ 
			$tabs[sanitize_key(basename(__FILE__, '.php'))] = __('Appearance Options', 'ci_theme');
			return $tabs; 
		}
	endif;

	// Default values for options go here.
	// $ci_defaults['option_name'] = 'default_value';
	// or
	// load_panel_snippet( 'snippet_name' );
	$ci_defaults['layout']      = 'default';
	$ci_defaults['textured_bg'] = 'textured';

	load_panel_snippet( 'color_scheme' );
	load_panel_snippet( 'custom_background' );

?>
<?php else: ?>

	<fieldset class="set">
		<p class="guide"><?php _e( 'Select the layout of the site. This affects every post/page/etc of the site.', 'ci_theme' ); ?></p>
		<?php
			$options = array(
				'default' => __( 'Default - Centered', 'ci_theme' ),
				'alt'     => __( 'Alternative - Left aligned', 'ci_theme' )
			);
			ci_panel_dropdown( 'layout', $options, __( 'Site layout', 'ci_theme' ) );
		?>
	</fieldset>

	<fieldset class="set">
		<p class="guide mt15"><?php _e( 'You can enable or disable the textured background of the sidebar.', 'ci_theme' ); ?></p>
		<?php ci_panel_checkbox( 'textured_bg', 'textured', __( 'Enable textured background', 'ci_theme' ) ); ?>
	</fieldset>

	<?php load_panel_snippet( 'color_scheme' ); ?>

	<?php load_panel_snippet( 'custom_background' ); ?>

<?php endif; ?>