<?php global $ci, $ci_defaults, $load_defaults; ?>
<?php if ($load_defaults===TRUE): ?>
<?php
	add_filter('ci_panel_tabs', 'ci_add_tab_portfolio_options', 50);
	if( !function_exists('ci_add_tab_portfolio_options') ):
		function ci_add_tab_portfolio_options($tabs) 
		{ 
			$tabs[sanitize_key(basename(__FILE__, '.php'))] = __('Portfolio Options', 'ci_theme'); 
			return $tabs; 
		}
	endif;

	// Default values for options go here.
	// $ci_defaults['option_name'] = 'default_value';
	// or
	// load_panel_snippet( 'snippet_name' );
	$ci_defaults['portfolio_single_height'] = '360';
	$ci_defaults['show_related_portfolios'] = 'enabled';
	$ci_defaults['related_portfolios_text'] = __( 'Related Projects', 'ci_theme' );

	load_panel_snippet('slider_flexslider_internal');

?>
<?php else: ?>

	<?php load_panel_snippet('slider_flexslider_internal'); ?>

	<fieldset class="set">
		<p class="guide"><?php echo sprintf( __( 'This option controls the height (in pixels) of the images appearing on the slider of each individual portfolio page. If you set this option to <strong>0</strong>, images will be resized proportionally. If you set it to any other integer number, the image will be automatically cropped to fit. In any case, the slider will be automatically resized to accommodate each image. Note that if you change the height, you will need to regenerate all your thumbnails using an appropriate plugin, such as the <a href="%s" target="_blank">Regenerate Thumbnails</a> plugin, otherwise your images may appear distorted.', 'ci_theme' ), 'http://wordpress.org/extend/plugins/regenerate-thumbnails/' ); ?></p>
		<?php ci_panel_input( 'portfolio_single_height', __( 'Portfolio slider height', 'ci_theme' ) ); ?>
	</fieldset>

	<fieldset class="set">
		<legend><?php _e( 'Related Projects', 'ci_theme' ); ?></legend>
		<p class="guide"><?php _e( 'You can show / hide the related projects section that appear beneath portfolio items.', 'ci_theme' ); ?></p>
		<fieldset class="mb10">
			<?php
				ci_panel_checkbox( 'show_related_portfolios', 'enabled', __( 'Show related projects.', 'ci_theme' ) );
				ci_panel_input( 'related_portfolios_text', __( 'Related projects title:', 'ci_theme' ) );
			?>
		</fieldset>
	</fieldset>

<?php endif; ?>