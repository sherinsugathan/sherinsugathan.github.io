<?php global $ci, $ci_defaults, $load_defaults, $content_width; ?>
<?php if ($load_defaults===TRUE): ?>
<?php
	add_filter('ci_panel_tabs', 'ci_add_tab_display_options', 30);
	if( !function_exists('ci_add_tab_display_options') ):
		function ci_add_tab_display_options($tabs) 
		{ 
			$tabs[sanitize_key(basename(__FILE__, '.php'))] = __('Display Options', 'ci_theme'); 
			return $tabs; 
		}
	endif;

	// Default values for options go here.
	// $ci_defaults['option_name'] = 'default_value';
	// or
	// load_panel_snippet( 'snippet_name' );
	$ci_defaults['hero_title']       = __( 'My name is <span>Nico</span> Escobar', 'ci_theme' );
	$ci_defaults['hero_description'] = 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Asperiores beatae consectetur magni. Earum magnam odit pariatur quas quis quos reprehenderit vitae! Aspernatur culpa cupiditate dolores ducimus eum excepturi hic non officiis, perferendis quae qui quo quos rem veniam veritatis. Exercitationem?';

	$ci_defaults['hero_show_front']     = 'enabled';
	$ci_defaults['hero_show_portfolio'] = 'enabled';
	$ci_defaults['hero_show_blog']      = 'enabled';
	$ci_defaults['hero_show_page']      = 'enabled';
	$ci_defaults['hero_show_search']    = 'enabled';
	$ci_defaults['hero_show_404']       = 'enabled';
	$ci_defaults['hero_show_default']   = 'enabled';

	load_panel_snippet('pagination');
	load_panel_snippet('excerpt');
	load_panel_snippet('comments');

	load_panel_snippet('featured_image_single');

	$ci_defaults['read_more_text'] = __('Read More <i class="fa fa-long-arrow-right"></i>', 'ci_theme');


	function ci_show_hero() {
		if ( is_page_template( 'template-front.php' ) ) {
			return ci_setting( 'hero_show_front' ) == 'enabled' ? true : false;
		} elseif ( is_singular( 'portfolio' ) ) {
			return ci_setting( 'hero_show_portfolio' ) == 'enabled' ? true : false;
		} elseif ( is_home() or is_singular( 'post' ) or is_archive() ) {
			return ci_setting( 'hero_show_blog' ) == 'enabled' ? true : false;
		} elseif ( is_page() ) {
			return ci_setting( 'hero_show_page' ) == 'enabled' ? true : false;
		} elseif ( is_search() ) {
			return ci_setting( 'hero_show_search' ) == 'enabled' ? true : false;
		} elseif ( is_404() ) {
			return ci_setting( 'hero_show_404' ) == 'enabled' ? true : false;
		}

		return ci_setting( 'hero_show_default' ) == 'enabled' ? true : false;
	}


	add_filter( 'ci-read-more-link', 'ci_theme_readmore', 10, 3 );
	if ( ! function_exists( 'ci_theme_readmore' ) ):
	function ci_theme_readmore( $html, $text, $link ) {
		return '<a class="entry-read-more" href="' . $link . '">' . $text . '</a>';
	}
	endif;

?>
<?php else: ?>

	<fieldset class="set">
		<p class="guide">
			<?php
				/* translators: %1$s is an opening HTML tag, and %2$s is the respective closing HTML tag, e.g. <span> and </span> */
				echo sprintf( __( 'Set your introduction title and introduction text here. This is complementary to the site\'s title and description, and it appears on top of all posts and pages. You can emphasize any piece of text by having <strong>%1$s</strong> in front of the text, and <strong>%2$s</strong> right after the text.', 'ci_theme' ),
					esc_html( '<span>' ),
					esc_html( '</span>' )
				);
			?>
		</p>
		<fieldset>
			<?php ci_panel_input( 'hero_title', __( 'Introduction title', 'ci_theme' ) ); ?>
			<?php ci_panel_input( 'hero_description', __( 'Introduction description', 'ci_theme' ) ); ?>
		</fieldset>

		<p class="guide"><?php _e( 'You can enable and disable the introduction title and text on individual types of pages. Uncheck the pages you don\'t want the intro to appear.', 'ci_theme' ); ?></p>
		<fieldset class="mb10">
			<?php ci_panel_checkbox( 'hero_show_front', 'enabled', __( 'Show on homepage.', 'ci_theme' ) ); ?>
			<?php ci_panel_checkbox( 'hero_show_portfolio', 'enabled', __( 'Show on portfolio pages.', 'ci_theme' ) ); ?>
			<?php ci_panel_checkbox( 'hero_show_blog', 'enabled', __( 'Show on blog and posts.', 'ci_theme' ) ); ?>
		</fieldset>
		<fieldset class="mb10">
			<?php ci_panel_checkbox( 'hero_show_page', 'enabled', __( 'Show on pages.', 'ci_theme' ) ); ?>
			<?php ci_panel_checkbox( 'hero_show_search', 'enabled', __( 'Show on search.', 'ci_theme' ) ); ?>
			<?php ci_panel_checkbox( 'hero_show_404', 'enabled', __( 'Show on 404.', 'ci_theme' ) ); ?>
		</fieldset>
		<fieldset class="mb10">
			<?php ci_panel_checkbox( 'hero_show_default', 'enabled', __( 'Show on all other cases.', 'ci_theme' ) ); ?>
		</fieldset>
	</fieldset>

	<?php load_panel_snippet('pagination'); ?>	

	<style type="text/css">
		#ci-panel-excerpt-preview-content { display: none; }
	</style>
	<?php load_panel_snippet('excerpt'); ?>

	<?php load_panel_snippet('comments'); ?>

	<?php load_panel_snippet('featured_image_single'); ?>

<?php endif; ?>