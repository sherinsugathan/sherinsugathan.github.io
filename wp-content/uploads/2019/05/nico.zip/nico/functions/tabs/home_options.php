<?php global $ci, $ci_defaults, $load_defaults; ?>
<?php if ($load_defaults===TRUE): ?>
<?php
	add_filter('ci_panel_tabs', 'ci_add_tab_homepage_options', 40);
	if( !function_exists('ci_add_tab_homepage_options') ):
		function ci_add_tab_homepage_options($tabs) 
		{ 
			$tabs[sanitize_key(basename(__FILE__, '.php'))] = __('Homepage Options', 'ci_theme'); 
			return $tabs; 
		}
	endif;
	
	// Default values for options go here.
	// $ci_defaults['option_name'] = 'default_value';
	// or
	// load_panel_snippet( 'snippet_name' );
	$ci_defaults['portfolio_cols']     = 3;
	$ci_defaults['home_portfolio_num'] = -1;
	$ci_defaults['home_blog_num']      = 3;

	if( !function_exists('ci_get_columns_class') ):
	function ci_get_columns_class( $cols ) {
		switch( $cols ){
			case 2: return 'col-md-6 col-sm-6 col-xs-6';
			case 4: return 'col-md-3 col-sm-6 col-xs-6';
			case 3:
			default: return 'col-md-4 col-sm-6 col-xs-6';
		}
	}
	endif;

?>
<?php else: ?>

	<fieldset class="set">
		<p class="guide"><?php _e('Control how many columns the portfolio area should be divided into. This only applies on the homepage.', 'ci_theme'); ?></p>
		<fieldset class="mb5">
			<?php
				$options = array();
				for ( $i = 2; $i <= 4; $i ++ ) {
					$options[ $i ] = sprintf( _n( '1 Column', '%s Columns', $i, 'ci_theme' ), $i );
				}
				ci_panel_dropdown( 'portfolio_cols', $options, __( 'Portfolio columns:', 'ci_theme' ) );
			?>
		</fieldset>
	</fieldset>

	<fieldset class="set">
		<p class="guide"><?php _e( 'Set the number of portfolio items shown on the front page, in a "most recent" fashion. For example, if you set this value to 5, and have 20 portfolio items of which 10 have the <strong>Show this portfolio item on the homepage</strong> option set, then only the 5 most recent items out of those 10 will be shown. To show all checked items, enter <strong>-1</strong>. Enter <strong>0</strong> to disable this section.', 'ci_theme' ); ?></p>
		<?php ci_panel_input( 'home_portfolio_num', __( 'Maximum portfolio items on homepage:', 'ci_theme' ) ); ?>
	</fieldset>

	<fieldset class="set">
		<p class="guide"><?php _e( 'Set the number of blog posts shown on the front page. Enter <strong>0</strong> to disable this section.', 'ci_theme' ); ?></p>
		<?php ci_panel_input( 'home_blog_num', __( 'Blog posts on homepage:', 'ci_theme' ) ); ?>
	</fieldset>

<?php endif; ?>