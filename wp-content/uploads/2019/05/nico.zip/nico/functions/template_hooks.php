<?php
add_filter( 'ci_footer_credits', 'ci_theme_footer_credits' );
if ( ! function_exists( 'ci_theme_footer_credits' ) ):
function ci_theme_footer_credits( $string ) {

	if ( ! CI_WHITELABEL ) {
		return sprintf( __( '<a href="%s">Powered by WordPress</a> - A theme by <a href="%s">CSSIgniter.com</a>', 'ci_theme' ),
			esc_url( 'https://wordpress.org' ),
			esc_url( 'http://www.cssigniter.com' )
		);
	} else {
		/* translators: %2$s is replaced by the website's name. */
		return sprintf( __( '<a href="%1$s">%2$s</a> - <a href="%3$s">Powered by WordPress</a>', 'ci_theme' ),
			esc_url( home_url() ),
			get_bloginfo( 'name' ),
			esc_url( 'https://wordpress.org' )
		);
	}

}
endif;

add_filter( 'body_class', 'ci_body_layout_class_names' );
if ( ! function_exists( 'ci_body_layout_class_names' ) ):
function ci_body_layout_class_names( $classes ) {
	if ( ci_setting( 'layout' ) == 'alt' ) {
		$classes[] = 'alt';
	}

	return $classes;
}
endif;

add_filter( 'body_class', 'ci_body_textured_class_names' );
if ( ! function_exists( 'ci_body_textured_class_names' ) ):
function ci_body_textured_class_names( $classes ) {
	if ( ci_setting( 'textured_bg' ) == 'textured' ) {
		$classes[] = 'textured';
	}

	return $classes;
}
endif;

add_filter( 'ci_custom_background_applied_element', 'ci_theme_custom_background_applied_element' );
if ( ! function_exists( 'ci_theme_custom_background_applied_element' ) ):
function ci_theme_custom_background_applied_element( $element ) {
	return 'body, body.textured';
}
endif;

add_filter( 'ci_custom_footer_background_applied_element', 'ci_theme_custom_footer_background_applied_element' );
if ( ! function_exists( 'ci_theme_custom_footer_background_applied_element' ) ):
function ci_theme_custom_footer_background_applied_element( $element ) {
	return '.footer, .textured .footer';
}
endif;
