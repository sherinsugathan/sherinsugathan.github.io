<?php
if( !class_exists('CI_Portfolio_Widget ') ):
class CI_Portfolio_Widget extends WP_Widget {

	function __construct(){
		$widget_ops  = array( 'description' => __( 'Displays a single Portfolio item', 'ci_theme' ) );
		$control_ops = array( /*'width' => 300, 'height' => 400*/ );
		parent::__construct( false, $name = __( '-= CI Portfolio =-', 'ci_theme' ), $widget_ops, $control_ops );

		// These are needed for compatibility with < v2.0
		add_filter( 'widget_display_callback', array( $this, '_rename_old_title_field' ), 10, 2 );
		add_filter( 'widget_form_callback', array( $this, '_rename_old_title_field' ), 10, 2 );
	}

	// This is needed for compatibility with < v2.0
	function _rename_old_title_field($instance, $_this) {
		$old_field = 'ci_title';
		$class     = get_class( $this );

		if ( get_class($_this) == $class && ! isset( $instance['title'] ) && isset( $instance[ $old_field ] ) ) {
			$instance['title'] = $instance[ $old_field ];
			unset( $instance[ $old_field ] );
		}

		return $instance;
	}

	function widget($args, $instance) {

		extract($args);
		$title      = apply_filters( 'widget_title', empty( $instance['title'] ) ? '' : $instance['title'], $instance, $this->id_base );
		$ci_post_id = $instance['ci_post_id'];

		$q = new WP_Query( array(
			'post_type' => 'portfolio',
			'p'         => $ci_post_id,
		) );

		if( $q->have_posts() ) {

			echo $before_widget;

			if ( ! empty( $title ) ) {
				echo $before_title . $title . $after_title;
			} else {
				echo $before_title . '<a href="' . esc_url( get_permalink() ) . '">' . get_the_title() . '</a>' . $after_title;
			}

			while ( $q->have_posts() ) {
				$q->the_post();

				?>
				<div class="item">
					<figure class="item-thumb">
						<a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
							<?php the_post_thumbnail(); ?>
						</a>
					</figure>

					<div class="item-content">
						<?php the_excerpt(); ?>
					</div>
				</div>
				<?php
			}

			echo $after_widget;
		}

	}

	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;

		$instance['title']   = sanitize_text_field( $new_instance['title'] );
		$instance['ci_post_id'] = intval( $new_instance['ci_post_id'] );

		return $instance;
	}
	 
	function form($instance){
		$instance = wp_parse_args( (array) $instance, array(
			'title'   => '',
			'ci_post_id' => 0,
		) );

		$title      = $instance['title'];
		$ci_post_id = $instance['ci_post_id'];

		echo '<p><label for="' . $this->get_field_id( 'title' ) . '">' . __( "Title (leave empty to use the portfolio's title):", 'ci_theme' ) . '</label><input id="' . $this->get_field_id( 'title' ) . '" name="' . $this->get_field_name( 'title' ) . '" type="text" value="' . esc_attr( $title ) . '" class="widefat" /></p>';
		echo '<p><label for="' . $this->get_field_id( 'ci_post_id' ) . '">' . __( 'Portfolio item to show:', 'ci_theme' ) . '</label></p>';
		wp_dropdown_posts( array(
			'post_type' => 'portfolio',
			'selected'  => $ci_post_id,
			'id'        => $this->get_field_id( 'ci_post_id' )
		), $this->get_field_name( 'ci_post_id' ) );
	}

} // class

register_widget('CI_Portfolio_Widget');

endif; // !class_exists
?>