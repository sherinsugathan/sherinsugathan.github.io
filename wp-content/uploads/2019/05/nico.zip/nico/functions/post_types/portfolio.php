<?php
//
// Portfolio Post Type related functions.
//
add_action( 'init', 'ci_create_cpt_portfolio' );
add_action( 'admin_init', 'ci_add_cpt_portfolio_meta' );
add_action( 'save_post', 'ci_update_cpt_portfolio_meta' );

if ( ! function_exists( 'ci_create_cpt_portfolio' ) ):
function ci_create_cpt_portfolio() {
	$labels = array(
		'name'               => _x( 'Portfolios', 'post type general name', 'ci_theme' ),
		'singular_name'      => _x( 'Portfolio', 'post type singular name', 'ci_theme' ),
		'add_new'            => __( 'New Portfolio', 'ci_theme' ),
		'add_new_item'       => __( 'Add New Portfolio', 'ci_theme' ),
		'edit_item'          => __( 'Edit Portfolio', 'ci_theme' ),
		'new_item'           => __( 'New Portfolio', 'ci_theme' ),
		'view_item'          => __( 'View Portfolio', 'ci_theme' ),
		'search_items'       => __( 'Search Portfolios', 'ci_theme' ),
		'not_found'          => __( 'No Portfolios found', 'ci_theme' ),
		'not_found_in_trash' => __( 'No Portfolios found in the trash', 'ci_theme' ),
		'parent_item_colon'  => __( 'Parent Portfolio:', 'ci_theme' )
	);

	$args = array(
		'labels'          => $labels,
		'singular_label'  => __( 'Portfolio', 'ci_theme' ),
		'public'          => true,
		'show_ui'         => true,
		'capability_type' => 'post',
		'hierarchical'    => false,
		'has_archive'     => false,
		'rewrite'         => array( 'slug' => _x( 'portfolio', 'post type slug', 'ci_theme' ) ),
		'menu_position'   => 5,
		'supports'        => array( 'title', 'editor', 'thumbnail', 'excerpt', 'comments' ),
		'menu_icon'       => 'dashicons-portfolio',
	);
	register_post_type( 'portfolio', $args );

}
endif;

if ( ! function_exists( 'ci_add_cpt_portfolio_meta' ) ):
function ci_add_cpt_portfolio_meta() {
	add_meta_box( 'ci_cpt_portfolio_meta', __( 'Portfolio Details', 'ci_theme' ), 'ci_add_cpt_portfolio_meta_box', 'portfolio', 'normal', 'high' );
}
endif;

if ( ! function_exists( 'ci_update_cpt_portfolio_meta' ) ):
function ci_update_cpt_portfolio_meta( $post_id ) {
	if ( ! ci_can_save_meta( 'portfolio' ) ) return;

	update_post_meta( $post_id, 'ci_cpt_portfolio_on_homepage', ci_sanitize_checkbox( $_POST['ci_cpt_portfolio_on_homepage'], 'enabled' ) );
	update_post_meta( $post_id, 'ci_cpt_portfolio_internal_slider', ci_sanitize_checkbox( $_POST['ci_cpt_portfolio_internal_slider'], 'disabled' ) );
	update_post_meta( $post_id, 'ci_cpt_portfolio_project_fields', ci_theme_sanitize_portfolio_project_repeating( $_POST ) );
	ci_metabox_gallery_save( $_POST );

}
endif;

if ( ! function_exists( 'ci_add_cpt_portfolio_meta_box' ) ):
function ci_add_cpt_portfolio_meta_box( $object, $box ) {
	ci_prepare_metabox( 'portfolio' );

	ci_metabox_open_collapsible( __( 'Portfolio Gallery', 'ci_theme' ) );
		?><p><?php _e( 'You can create a slider for your portfolio item by pressing the "Add Images" button below. You should also set a featured image that will be used as this portfolio item\'s cover.', 'ci_theme' ); ?></p><?php
		ci_metabox_gallery();
	ci_metabox_close_collapsible();

	ci_metabox_checkbox( 'ci_cpt_portfolio_on_homepage', 'enabled', __('Show this portfolio item on the homepage.', 'ci_theme') );
	ci_metabox_checkbox( 'ci_cpt_portfolio_internal_slider', 'disabled', __('Disable the internal portfolio slider (displayed when this portfolio is viewed).', 'ci_theme') );

	ci_metabox_open_collapsible( __( 'Project Details', 'ci_theme' ) );
	?>
	<p><?php _e( 'You need to enter at least a description for each entry. You may re-arrange items by drag and drop.', 'ci_theme' ); ?></p>
	<fieldset class="project_fields ci-repeating-fields">
		<div class="inner">
			<?php
				$fields = get_post_meta( $object->ID, 'ci_cpt_portfolio_project_fields', true );

				if ( ! empty( $fields ) ) {
					foreach( $fields as $field ) {
						?>
						<div class="post-field">
							<label><?php _e( 'Title:', 'ci_theme' ); ?> <input type="text" name="ci_cpt_portfolio_project_repeatable_title[]" value="<?php echo esc_attr( $field['title'] ); ?>" class="widefat" /></label>
							<label><?php _e( 'Description:', 'ci_theme' ); ?> <input type="text" name="ci_cpt_portfolio_project_repeatable_description[]" value="<?php echo esc_attr( $field['description'] ); ?>" class="widefat" /></label>
							<p class="ci-repeating-remove-action"><a href="#" class="button ci-repeating-remove-field"><i class="dashicons dashicons-dismiss"></i><?php _e( 'Remove me', 'ci_theme' ); ?></a></p>
						</div>
						<?php
					}
				}
				?>
				<div class="post-field field-prototype" style="display: none;">
					<label><?php _e( 'Title:', 'ci_theme' ); ?> <input type="text" name="ci_cpt_portfolio_project_repeatable_title[]" value="" class="widefat" /></label>
					<label><?php _e( 'Description:', 'ci_theme' ); ?> <input type="text" name="ci_cpt_portfolio_project_repeatable_description[]" value="" class="widefat" /></label>
					<p class="ci-repeating-remove-action"><a href="#" class="button ci-repeating-remove-field"><i class="dashicons dashicons-dismiss"></i><?php _e( 'Remove me', 'ci_theme' ); ?></a></p>
				</div>
		</div>
		<a href="#" class="ci-repeating-add-field button"><i class="dashicons dashicons-plus-alt"></i><?php _e('Add Field', 'ci_theme'); ?></a>
	</fieldset>
	<?php
	ci_metabox_close_collapsible();

}
endif;

if ( ! function_exists( 'ci_theme_sanitize_portfolio_project_repeating' ) ) :
function ci_theme_sanitize_portfolio_project_repeating( $POST_array ) {
	if ( empty( $POST_array ) || !is_array( $POST_array ) ) {
		return false;
	}

	$titles       = $POST_array['ci_cpt_portfolio_project_repeatable_title'];
	$descriptions = $POST_array['ci_cpt_portfolio_project_repeatable_description'];

	$count = max( count( $titles ), count( $descriptions ) );

	$new_fields = array();

	$records_count = 0;
	for ( $i = 0; $i < $count; $i++ ) {
		if ( empty( $descriptions[ $i ] ) ) {
			continue;
		}

		$new_fields[ $records_count ]['title']       = sanitize_text_field( $titles[ $i ] );
		$new_fields[ $records_count ]['description'] = wp_kses( $descriptions[ $i ], wp_kses_allowed_html( 'post' ) );
		$records_count++;
	}

	return $new_fields;
}
endif;
