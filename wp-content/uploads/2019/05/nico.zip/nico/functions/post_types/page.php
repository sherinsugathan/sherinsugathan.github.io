<?php
//
// Page Post Type related functions.
//
add_action( 'admin_init', 'ci_add_cpt_page_header_bg_meta' );
add_action( 'save_post', 'ci_update_cpt_page_header_bg_meta' );

if ( ! function_exists( 'ci_add_cpt_page_header_bg_meta' ) ):
function ci_add_cpt_page_header_bg_meta() {
	add_meta_box( 'ci_cpt_page_portfolio_listing_meta', __( 'Portfolio Listing Details', 'ci_theme' ), 'ci_add_cpt_page_portfolio_listing_meta_box', 'page', 'normal', 'high' );
}
endif;

if ( ! function_exists( 'ci_update_cpt_page_header_bg_meta' ) ):
function ci_update_cpt_page_header_bg_meta( $post_id ) {

	if ( ! ci_can_save_meta( 'page' ) ) return;

	update_post_meta( $post_id, 'ci_cpt_portfolio_columns', absint( $_POST['portfolio_columns'] ) );
}
endif;

if ( ! function_exists( 'ci_add_cpt_page_portfolio_listing_meta_box' ) ):
function ci_add_cpt_page_portfolio_listing_meta_box( $object, $box ) {
	ci_prepare_metabox( 'page' );

	?><p><?php _e( 'Select how many columns your portfolio listing will be divided into.', 'ci_theme' ); ?></p><?php

	$options = array();
	for ( $i = 2; $i <= 4; $i ++ ) {
		$options[ $i ] = sprintf( _n( '1 Column', '%s Columns', $i, 'ci_theme' ), $i );
	}
	ci_metabox_dropdown( 'ci_cpt_portfolio_columns', $options, __('Portfolio columns', 'ci_theme') );

	ci_bind_metabox_to_page_template( 'ci_cpt_page_portfolio_listing_meta', 'template-portfolio-listing.php', 'cpt_portfolio_metabox' );
}
endif;
