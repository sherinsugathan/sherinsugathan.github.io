<?php
	register_nav_menus( array(
		'ci_main_menu' => __( 'Main Menu', 'ci_theme' )
	) );
