<?php get_header(); ?>

<main class="main">
	<?php get_template_part( 'inc_hero' ); ?>

	<?php while ( have_posts() ) : the_post(); ?>
		<article id="post-<?php the_ID(); ?>" <?php post_class( 'entry' ); ?>>
			<div class="row">

				<div class="col-md-4 col-sm-5 col-xs-4">
					<?php if( has_post_thumbnail() ): ?>
						<figure class="entry-thumb">
							<a href="<?php the_permalink(); ?>">
								<?php the_post_thumbnail(); ?>
							</a>
						</figure>
					<?php endif; ?>
				</div>

				<div class="col-md-8 col-sm-7 col-xs-8">
					<h1 class="entry-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h1>

					<div class="entry-meta">
						<?php
							/* translators: %1$s is a date. %2$s is a linked number of comments wording. E.g. Posted on <time class="entry-time" datetime="2015-03-03">March 13, 2015</time> &bull; <a href="single.html#comments">5 Comments</a> */
							echo sprintf( __( 'Posted on %1$s &bull; %2$s', 'ci_theme' ),
								sprintf( '<time class="entry-time" datetime="%s">%s</time>',
									esc_attr( get_the_date( 'c' ) ),
									get_the_date()
								),
								sprintf( '<a href="%s">%s</a>',
									get_comments_link(),
									get_comments_number_text()
								)
							);
						?>
					</div>

					<div class="entry-excerpt">
						<?php the_excerpt(); ?>
					</div>

					<?php ci_read_more(); ?>
				</div>

			</div>
		</article>
	<?php endwhile; ?>

	<?php ci_pagination(); ?>

</main>

<?php get_footer(); ?>