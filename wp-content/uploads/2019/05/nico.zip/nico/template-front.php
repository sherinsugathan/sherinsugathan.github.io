<?php
/*
Template Name: Front Page
*/
?>

<?php get_header(); ?>

<main class="main">
	<?php get_template_part( 'inc_hero' ); ?>

	<?php
		$portfolio_num = ci_setting( 'home_portfolio_num' );
		$blog_num      = ci_setting( 'home_blog_num' );
	?>
	<?php if ( ! empty( $portfolio_num ) ) : ?>
		<?php
			$q = new WP_Query( array(
				'post_type'      => 'portfolio',
				'posts_per_page' => $portfolio_num,
				'meta_query'     => array(
					array(
						'key'     => 'ci_cpt_portfolio_on_homepage',
						'value'   => 'enabled',
						'compare' => '=',
					),
				)
			) );
		?>
		<?php if ( $q->have_posts() ) : ?>
			<?php
				$skills = array();
				while ( $q->have_posts() ) {
					$q->the_post();
					$item_skills = get_the_terms( get_the_ID(), 'skill' );
					foreach ( $item_skills as $skill ) {
						$skills[ $skill->term_id ] = $skill;
					}
				}
				$q->rewind_posts();
			?>
			<ul class="filter-nav">
				<li><a href="#filter" class="selected" data-filter="*"><?php esc_html_e( 'All Works', 'ci_theme' ); ?></a></li>
				<?php foreach ( $skills as $skill ) : ?>
					<li><a href="#filter" data-filter=".term-<?php echo esc_attr( $skill->term_id ); ?>"><?php echo esc_html( $skill->name ); ?></a></li>
				<?php endforeach; ?>
			</ul>
			<div class="row item-list item-isotope">
				<?php while ( $q->have_posts() ) : $q->the_post(); ?>
					<?php
						$terms         = get_the_terms( get_the_ID(), 'skill' );
						$terms         = ! empty( $terms ) ? $terms : array();
						$terms_classes = implode( ' ', array_map( 'urldecode', wp_list_pluck( $terms, 'slug' ) ) );
						foreach ( wp_list_pluck( $terms, 'term_id' ) as $term_id ) {
							$terms_classes .= ' term-' . $term_id;
						}
					?>
					<div class="<?php echo esc_attr( ci_get_columns_class( ci_setting( 'portfolio_cols' ) ) ); ?> <?php echo esc_attr( $terms_classes ); ?>">
						<div class="item">
							<a href="<?php the_permalink(); ?>">
								<?php the_post_thumbnail( 'ci_portfolio_thumb' ); ?>
							</a>
						</div>
					</div>
				<?php endwhile; ?>
			</div>
			<?php wp_reset_postdata(); ?>
		<?php endif; ?>
	<?php endif; ?>

	<?php if ( ! empty( $blog_num ) ) : ?>
		<section class="home-blog">
			<h3 class="section-title"><?php _e( 'From the blog', 'ci_theme' ); ?></h3>

			<?php
				$q = new WP_Query( array(
					'post_type'      => 'post',
					'posts_per_page' => $blog_num,
				) );
			?>
			<?php while ( $q->have_posts() ) : $q->the_post(); ?>
				<article id="post-<?php the_ID(); ?>" <?php post_class( 'entry' ); ?>>
					<div class="row">

						<div class="col-md-4 col-sm-5 col-xs-4">
							<?php if ( has_post_thumbnail() ): ?>
								<figure class="entry-thumb">
									<a href="<?php the_permalink(); ?>">
										<?php the_post_thumbnail(); ?>
									</a>
								</figure>
							<?php endif; ?>
						</div>

						<div class="col-md-8 col-sm-7 col-xs-8">
							<h1 class="entry-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h1>

							<div class="entry-meta">
								<?php
									/* translators: %1$s is a date. %2$s is a linked number of comments wording. E.g. Posted on <time class="entry-time" datetime="2015-03-03">March 13, 2015</time> &bull; <a href="single.html#comments">5 Comments</a> */
									echo sprintf( __( 'Posted on %1$s &bull; %2$s', 'ci_theme' ),
										sprintf( '<time class="entry-time" datetime="%s">%s</time>',
											esc_attr( get_the_date( 'c' ) ),
											get_the_date()
										),
										sprintf( '<a href="%s">%s</a>',
											esc_url( get_comments_link() ),
											get_comments_number_text()
										)
									);
								?>
							</div>

							<div class="entry-excerpt">
								<?php the_excerpt(); ?>
							</div>

							<?php ci_read_more(); ?>
						</div>

					</div>
				</article>
			<?php endwhile; ?>

			<?php wp_reset_postdata(); ?>
		</section>
	<?php endif; ?>
</main>

<?php get_footer(); ?>
