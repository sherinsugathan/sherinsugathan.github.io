<?php get_header(); ?>

<main class="main">
	<?php get_template_part( 'inc_hero' ); ?>

	<article class="entry">
		<h1 class="entry-title"><?php _e( 'Not Found', 'ci_theme' ); ?></h1>

		<div class="entry-content">
			<p><?php _e( 'Oh, no! The page you requested could not be found. Perhaps searching will help...', 'ci_theme' ); ?></p>
			<?php get_search_form(); ?>
		</div>

		<?php ci_read_more(); ?>
	</article>

</main>

<?php get_footer(); ?>