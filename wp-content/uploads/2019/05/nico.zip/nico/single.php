<?php get_header(); ?>

<main class="main">
	<?php get_template_part( 'inc_hero' ); ?>

	<?php while ( have_posts() ) : the_post(); ?>

		<article id="post-<?php the_ID(); ?>" <?php post_class( 'entry' ); ?>>
			<h1 class="entry-title"><?php the_title(); ?></h1>

			<div class="entry-meta">
				<?php
					/* translators: %1$s is a date. %2$s is a comma-sparated list of categories. %3$s is a linked number of comments wording. E.g. Posted on <time class="entry-time" datetime="2015-03-03">March 13, 2015</time> &bull; Posted Under <a href="">News</a>, <a href="">Articles</a> &bull; <a href="single.html#comments">5 Comments</a> */
					echo sprintf( __( 'Posted on %1$s &bull; Posted Under %2$s &bull; %3$s', 'ci_theme' ),
						sprintf( '<time class="entry-time" datetime="%s">%s</time>',
							esc_attr( get_the_date( 'c' ) ),
							get_the_date()
						),
						get_the_category_list( ', ' ),
						sprintf( '<a href="%s">%s</a>',
							get_comments_link(),
							get_comments_number_text()
						)
					);
				?>
			</div>

			<?php if( ci_has_image_to_show() ): ?>
				<figure class="entry-thumb <?php ci_e_setting( 'featured_single_align' ); ?>">
					<a href="<?php echo ci_get_featured_image_src( 'large' ); ?>" class="lightbox">
						<?php ci_the_post_thumbnail( array( 'noalign' => true ) ); ?>
					</a>
				</figure>
			<?php endif; ?>

			<div class="entry-content">
				<?php the_content(); ?>
				<?php wp_link_pages(); ?>
			</div>

		</article>

		<?php comments_template(); ?>

	<?php endwhile; ?>

</main>

<?php get_footer(); ?>